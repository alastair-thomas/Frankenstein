
text_to_Vecs <- function(model_choice){
  
  if (model_choice == 'test') {
    file_list <- list.files(path="/cloud/project/FunctionWords/test_model/", pattern="*.txt", full.names=TRUE, recursive=FALSE)
    
    df <- data.frame(colnames<-c(1:70))
    
    for (f in file_list){
      row <- scan(file=f, sep=",")
      tempdf <- 
      print(row)
    }
      
    
    
  }
  else {
    
  }
  
  return(dataset)
}


#X <- text_to_Vecs('test')
#X


df <- data.frame()

df[0] <- c(1,2,3)
df

